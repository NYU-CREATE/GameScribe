﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CGE.Gopher;

public class RealTimeUpdater : Singleton<RealTimeUpdater>
{
	private string _destinationNest = "DREAM";
	private string _actionName = "realTimeUpdate";

	public void DoRealTimeUpdate (string writer, string jotJSON)
	{
		RealTimeUpdate realTimeUpdate = new RealTimeUpdate (writer, jotJSON);
		Nest.Get.gopherGo (_destinationNest, _actionName, realTimeUpdate, null);
	}

	private class RealTimeUpdate
	{
		public string realTimeUpdateKey;
		public string realTimeUpdateValue;

		public RealTimeUpdate (string key, string value)
		{
			realTimeUpdateKey = key;
			realTimeUpdateValue = value;
		}
	}
}
