﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Newtonsoft.Json;

namespace CGE.GameScribe {

    public delegate void GSDirectRegDel(string sheetID);
    delegate void ApiReturnDelegate(string apiReceipt);

    public class GameScribeDirect : MonoBehaviour {
        //CONSTANTS
		private const bool TESTING = false;

        private const string KEY_API_ACTION = "apiAction";
        private const string KEY_GS_VERSION = "gsVersion";
        private const string KEY_PACKAGE = "package";
        private const string WRITER = "gamescribe";

        //Public Properties


        //Private Properties
        private float _scribeHz = 2;
        //private int _maxDataFields = 4;
        //private int _minDataFields = 0;
        //private string _commaReplace = "~";
        //private int _submitTimeout = 5000;
        private int[] _timerArray = new int[] { 10,
                                                15,
                                                30,
                                                60,
                                                120,
                                                240,
                                                480,
                                                960,
                                                1800,
                                                1800,
                                                1800,
                                                1800,
                                                1800,
                                                1800,
                                                1800,
                                                1800,
                                                3600,
                                                3600};
        private int _maxUploadSize = 256000;
        private RegObject _regObj;
        private List<DirectJot> _jots = new List<DirectJot>();
        private List<DirectJot> _tempJots = new List<DirectJot>();
        private string _sheetID;
        private string _userID;
        private int _jotIncrem = 0;
        private int _apiID = 0;
        private GSDirectRegDel _gsdRegDel;
        private int _dIndex = 0;
        private bool _running = false;
        private bool _spiderStarted = false;
        private bool _closing = false;
        private bool _cycling = false;

        private IEnumerator i_cycleSpider;
        private IEnumerator i_flagDelay;


        //Constructor

        //Accessors

        //Public Methods
        public void init(RegObject regObject, GSDirectRegDel handleDirectReg) {
            _regObj = regObject;
            _gsdRegDel = handleDirectReg;
            string guid = Guid.NewGuid().ToString();
            _sheetID = guid.Substring(0, 8);
            _userID = _sheetID + "_" + guid.Substring(guid.Length-12);
            //StartCoroutine(wwwSend());
            WWWForm jotPack = new WWWForm();
            jotPack.AddField(KEY_API_ACTION, ApiAction.GET_MAX_POST);
            jotPack.AddField(KEY_GS_VERSION, _regObj.ver);
            StartCoroutine(apiSend(jotPack));
            _gsdRegDel(_sheetID);
        }

        public void startSpider(string gameUserID) {
            if (!_spiderStarted) {
                _running = true;
                _spiderStarted = true;
                this.setTimer(0);
            }
        }

        public void recordJot(Jot jot) {
            if (!_closing) {
                DirectJot dJot = this.formatJot(jot);
                dJot.sheetKey = null;
                if (_cycling) {
                    _tempJots.Add(dJot);
                } else {
                    _jots.Add(dJot);
                }
            }
        }

        public int getTimer() {
            return (int)(Time.realtimeSinceStartup * 1000);
        }

        //Private Methods        
        private DirectJot formatJot(Jot jot) {
            DirectJot dJot = new DirectJot(jot);
            dJot.id = _jotIncrem++;
            return dJot;
        }

        private int registerNextApiID() { return _apiID++; }
    
    //Spider Methods ****************************************************************
        private void setTimer(int newIndex) {
            if (i_cycleSpider != null) StopCoroutine(i_cycleSpider);
            if (i_flagDelay != null) StopCoroutine(i_flagDelay);
            _dIndex = newIndex;
            if (!_closing) {
                if (_dIndex < _timerArray.Length) {
                    i_cycleSpider = cycleSpider();
                    i_flagDelay = flagDelay();
                    StartCoroutine(i_cycleSpider);
                    StartCoroutine(i_flagDelay);
                } else {
                    this.submit9999();
                }
            } else {
                if (_jots.Count > 0) {
                    i_cycleSpider = cycleSpider();
                    StartCoroutine(i_cycleSpider);
                } else {
                    _running = false;
                }
            }
        }

        private IEnumerator cycleSpider() {
            yield return new WaitForSeconds(1 / _scribeHz);
            _cycling = true;
            List<DirectJot> hopper = new List<DirectJot>();
            List<DirectJot> toSubmit = new List<DirectJot>();
            bool newJots = false;
            while (_jots.Count > 0) {
                DirectJot popJot = _jots[0];
                _jots.RemoveAt(0);
                if (!popJot.sent && !popJot.submitting) {
                    if (popJot.gameCode < 9000) newJots = true;
                    if (toSubmit.Count < 5000) {
                        popJot.submitting = true;
                        toSubmit.Add(popJot);
                    }
                }
                if (!popJot.complete) hopper.Add(popJot);
            }
            _jots = hopper;
            if (toSubmit.Count > 0) this.submitJots(toSubmit);
            while (_tempJots.Count > 0) {
                _jots.Add(_tempJots[0]);
                _tempJots.RemoveAt(0);
            }
            _cycling = false;
            if (newJots) {
                //Debug.Log("new jots: " + toSubmit.Count + " :: " + Time.realtimeSinceStartup);
                this.setTimer(0);
            } else {
                i_cycleSpider = cycleSpider();
                StartCoroutine(i_cycleSpider);
            }
        }

        private IEnumerator flagDelay() {
            yield return new WaitForSeconds(_timerArray[_dIndex]);
            //Debug.Log("flagDelay: " + _timerArray[_dIndex] + " :: " + Time.realtimeSinceStartup);
            _jots.Add(this.newTimerJot(GSgameCodes.NO_RECORDS_REPORTED, _timerArray[_dIndex]));
            this.setTimer(_dIndex + 1);
        }

        private void submit9999() {
            int totTime = 0;
            for (int i = 0; i < _timerArray.Length; i++) {
                totTime += _timerArray[i];
            }
            _jots.Add(this.newTimerJot(GSgameCodes.GAME_TIMED_OUT, totTime));
            this.closeSheet();
        }

        private DirectJot newTimerJot(int code, int seconds) {
            Jot jot = new Jot {
                gameCode = code,
                writer = WRITER,
                gameTime = this.getTimer(),
                d01 = Convert.ToString(seconds)
            };
            return this.formatJot(jot);
        }   

    //Jot Submission **********************************************************************
        private void submitJots(List<DirectJot> jots) {
            //Debug.Log("new jotPack -----------------------------------");
            switch (_regObj.mode) {
                case "off":
                    for (int i = 0; i < jots.Count; i++) {
                        jots[i].sent = true;
                        jots[i].complete = true;    
                    }
                    if (_closing) this.allCompleteCheck();
                    break;
                case "trace":
                    for (int i = 0; i < jots.Count; i++) {
                        jots[i].sent = true;
                        jots[i].complete = true;
                        Debug.Log(_jots[i].toString());
                    }
                    if (_closing) this.allCompleteCheck();
                    break;
                case "permissive":
                    this.sendJots(jots, false);
                    break;
                case "strict":
                    this.sendJots(jots, true);
                    break;
            }
        }

        private void sendJots(List<DirectJot> jots, bool waitOnReceipt) {
            WWWForm jotPack = new WWWForm();
            jotPack.AddField(KEY_API_ACTION, ApiAction.JOT_DOWN);
            jotPack.AddField(KEY_GS_VERSION, _regObj.ver);
            jotPack.AddField("userID", _userID);
            jotPack.AddField("gameKey", _regObj.gameKey);
            jotPack.AddField("sheetKey", _sheetID);
            jotPack.AddField("jotCount", jots.Count);
            jotPack.AddField("jotSet", JsonConvert.SerializeObject(jots));

            //Debug.Log("size: " + ser.Length + ", " + System.Text.ASCIIEncoding.Unicode.GetByteCount(ser));
            StartCoroutine(apiSend(jotPack));
        }

    //WWW send and receive **************************************************************
        private IEnumerator apiSend(WWWForm postData) {
            if (TESTING) postData.AddField("QA", "true");
            WWW www = new WWW(_regObj.url, postData);

            yield return www;
            if (www.error == null) {
                //Debug.Log("gs return: " + www.text);
                this.apiCapture(JsonConvert.DeserializeObject<ApiReceipt>(www.text));
            } else {
                Debug.Log("error: " + www.error);
                /* ************************************** */
                // Put the jot local saving stuff here
                /* ************************************** */
            }
        }

        private void apiCapture(ApiReceipt apiReceipt) {
            if (apiReceipt.success) {
                switch (apiReceipt.requestedAction) {
                    case ApiAction.GET_MAX_POST:
                        _maxUploadSize = apiReceipt.maxBytes;
                        break;
                    case ApiAction.JOT_DOWN:
                        for (int i = 0; i < apiReceipt.jotReceipts.Count; i++) {
                            DirectJot jot = this.jotByID(apiReceipt.jotReceipts[i].jotID);
                            if (jot.id != -1) {
                                if (apiReceipt.jotReceipts[i].success) {
                                    jot.complete = true;
                                } else {
                                    jot.sent = false;
                                    jot.submitting = false;
                                }
                            }
                        }
                        this.allCompleteCheck();
                        break;
                }
            }
        }

        private DirectJot jotByID(int jotID) {
            for (int i = 0; i < _jots.Count; i++) {
                if (_jots[i].id == jotID) return _jots[i];
            }
            return new DirectJot { id = -1 };
        }

        private void allCompleteCheck() {
            bool finished = true;
            for (int i = 0; i < _jots.Count; i++) {
                if (!_jots[i].complete) {
                    finished = false;
                    break;
                }
            }
            if (finished) {
                _running = false;
            }
        }

        private void closeSheet() {
            if (!_closing) {
                _closing = true;
                StopCoroutine(i_cycleSpider);
                StopCoroutine(i_flagDelay);
                while (_tempJots.Count > 0) {
                    _jots.Add(_tempJots[0]);
                    _tempJots.RemoveAt(0);
                }
                if (_jots.Count == 0) {
                    _running = false;
                } else {
                    this.setTimer(0);
                }
            }

        }




    }

}
