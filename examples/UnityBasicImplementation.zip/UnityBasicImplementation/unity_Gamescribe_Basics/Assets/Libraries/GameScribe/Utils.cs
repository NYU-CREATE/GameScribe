﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CGE.GameScribe {

	[System.Serializable]
	public class Jot {
		public string sheetKey; 
		public int gameCode; 
		public string writer; 
		public int gameTime;  
		public string d01;  
		public string d02;  
		public string d03; 
		public string d04;

        public string toString() {
            string jd = "jot -- ";
            jd += "gameCode: " + gameCode + ", ";
            jd += "writer: " + writer + ", ";
            jd += "gameTime: " + gameTime;
            if (d01 != null && d01.Length > 0) jd += ", d01: " + d01;
            if (d02 != null && d02.Length > 0) jd += ", d02: " + d02;
            if (d03 != null && d03.Length > 0) jd += ", d03: " + d03;
            if (d04 != null && d04.Length > 0) jd += ", d04: " + d04;
            return jd;
        }

    }

    public class RegObject {
        public string src { get; set; }
        public string ver { get; set; }
        public string gameName { get; set; }
        public string gameKey { get; set; }
        public string mode { get; set; }
        public string url { get; set; }
        public string environment { get; set; }
        public string goName { get; set; }
        public string captureFxn { get; set; }
        public string uKey { get; set; }
    }

    class DirectJot : Jot {
        public int id { get; set; }
        public bool sent = false;
        public bool submitting = false;
        public bool complete = false;

        public DirectJot() {}
        public DirectJot(Jot jot) {
            sheetKey = jot.sheetKey;
            gameCode = jot.gameCode;
            writer = jot.writer;
            gameTime = jot.gameTime;
            d01 = jot.d01;
            d02 = jot.d02;
            d03 = jot.d03;
            d04 = jot.d04;
        }
    }

    static class GSgameCodes {
        public const int GS_REGISTERED = 9001; //GS instance [id] registered a [name] to sheet [key] version [gsVersion];
        public const int GS_LAUNCHED = 9101; //GS sheet launched with local game id [gameUserID];
        public const int NO_RECORDS_REPORTED = 9995; //No records to report after [delayTime] millisecond delay;
        public const int GAME_TIMED_OUT = 9999; //RECORDING STOPPED.  No activity for [total delayTime] minutes;
    }

    static class ApiAction {
        public const string GET_MAX_POST = "maxPostSize";
        public const string JOT_DOWN = "jotDown";
        public const string CHECK_KEY = "checkGameKey";  
    }

    class ApiReceipt {
        public bool success { get; set; }
        public string requestedAction { get; set; }
        public string gsVersion { get; set; }
        public string sheetID { get; set; }
        public int jotCount { get; set; }
        public int maxBytes { get; set; }
        public List<JotReceipt> jotReceipts { get; set; }
    }

    class JotReceipt {
        public int jotID { get; set; }
        public bool success { get; set; }
    }


}
