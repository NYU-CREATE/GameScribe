﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System;
using CGE.GameScribe;

public delegate void GSregDelegate(bool success);

public class GameScribe : MonoBehaviour
{
   
    private const string SRC = "sdk";
    private const string ENVIRONMENT = "unity";
    private const string VERSION = "v1p2";
    private const string FXN_REGISTER = "gamescribe.register";
    private const string FXN_LAUNCH = "gamescribe.launch";
    private const string FXN_JOT_DOWN = "gamescribe.jotDown";
    private const string FXN_CLOSE = "gamescribe.closeSheet";
    private const string GAME_NAME = "game";
    private const string GO_NAME = "GameScribe";
    private const string GO_CAPTURE_FXN = "shellCapture";
    private const string GS_EVAL = "window.gamescribe=window.gamescribe||{};";
	
    private static GameScribe _sheet;
    private static string _uKey;

    private enum Status
    {
        UNIN,
        UNRG,
        REGR,
        LNCH,
        CLSD}

    ;

    private Status _status = Status.UNIN;
    private RegObject _reg;
    private string _sheetKey;
    private string _mode = "off";
    private GameObject _callbackGO;
    private string _callbackFxn;
    private Boolean _holdingCallback = false;
    private string _editorReg = "{\"signal\":\"registered\",\"success\":true,\"sheetKey\":\"ApplicationIsEditor\"}";
    private List<Jot> _preRegJots = new List<Jot>();
    private GSregDelegate _regDel;
    private bool _hasRegDel = false;

    private GameScribeDirect _gsDirect;

    public static GameScribe Sheet
    {
        get { return _sheet ?? (_sheet = initNewSheet()); }
    }
    void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }

    private static GameScribe initNewSheet()
    {
        
        _uKey = Guid.NewGuid().ToString();
        if (!Application.isEditor)
        {
            string ev = GS_EVAL +
                        FXN_CLOSE + "=" + FXN_CLOSE + "||function(){};" +
                        FXN_JOT_DOWN + "=" + FXN_JOT_DOWN + "||function(){};" +
                        FXN_LAUNCH + "=" + FXN_LAUNCH + "||function(){};" +
                        FXN_REGISTER + "=" + FXN_REGISTER + "||function(){};";
            Application.ExternalEval(ev);
        }
        return new GameObject("GameScribe").AddComponent<GameScribe>();
    }

    public void register(String gameKey, String mode, String url, GameObject listenerGO, string listenerFxn)
    {
        if ((int)_status < (int)Status.REGR)
        {
            _mode = mode.ToLower();
            _reg = new RegObject
            {
                src = SRC,
                ver = VERSION,
                gameName = GAME_NAME,
                gameKey = gameKey,
                mode = _mode,
                url = url,
                environment = ENVIRONMENT,
                goName = GO_NAME,
                captureFxn = GO_CAPTURE_FXN,
                uKey = _uKey
            };
            if (!_holdingCallback)
            {
                _callbackGO = listenerGO;
                _callbackFxn = listenerFxn;
            }
            _holdingCallback = true;
            if (Application.isEditor)
            {
                shellCapture(_editorReg);
            }
            else
            {
                Application.ExternalCall(FXN_REGISTER, jsonStringify(_reg));
            }
        }
        else
        {
            listenerGO.SendMessage(listenerFxn, false);
        }
    }

    public void register(String gameKey, String mode, String url, GSregDelegate registeredListener)
    {
        if ((int)_status < (int)Status.REGR)
        {
            _mode = mode;
            _reg = new RegObject
            {
                src = SRC,
                ver = VERSION,
                gameName = GAME_NAME,
                gameKey = gameKey,
                mode = _mode,
                url = url,
                environment = ENVIRONMENT,
                goName = GO_NAME,
                captureFxn = GO_CAPTURE_FXN,
                uKey = _uKey
            };
            if (!_holdingCallback)
            {
                _regDel = registeredListener;
                _hasRegDel = true;
            }
            _holdingCallback = true;
            if (Application.isEditor)
            {
                shellCapture(_editorReg);
            }
            else
            {
                Application.ExternalCall(FXN_REGISTER, jsonStringify(_reg));
            }
        }
        else
        {
            registeredListener(false);
        }
    }

    public void registerDirect(String gameKey, String mode, String url, GSregDelegate registeredListener, string userID)
    {
        if ((int)_status < (int)Status.REGR)
        {
            _mode = mode;
            _reg = new RegObject
            {
                src = SRC,
                ver = VERSION,
                gameName = GAME_NAME,
                gameKey = gameKey,
                mode = _mode,
                url = url,
                environment = ENVIRONMENT,
                goName = GO_NAME,
                captureFxn = GO_CAPTURE_FXN,
                uKey = _uKey
            };
            if (!_holdingCallback)
            {
                _regDel = registeredListener;
                _hasRegDel = true;
            }
            _holdingCallback = true;

            _gsDirect = this.gameObject.AddComponent<GameScribeDirect>();
            _gsDirect.init(_reg, directRegistered);
        }
        else
        {
            registeredListener(false);
        }

    }

	public void unregister () {
		_status = Status.UNIN;
		_reg = null;
		_sheetKey = null;
		_mode = "off";
		_callbackGO = null;
		_callbackFxn = null;
		_holdingCallback = false;
		_preRegJots = new List<Jot>();
		_regDel = null;
		_hasRegDel = false;
		_gsDirect = null;
	}

    public void launch(string gameUserID)
    {
        if ((int)_status == (int)Status.REGR)
        {
            if (_gsDirect != null)
            {
                _gsDirect.startSpider(gameUserID);
            }
            else if (!Application.isEditor)
            {
                Application.ExternalCall(FXN_LAUNCH, _sheetKey, gameUserID);
            }
            _status = Status.LNCH;
            foreach (Jot jot in _preRegJots)
            {
                this.submitJot(jot);
            }
            _preRegJots = new List<Jot>();
        }
    }

    public bool isRegistered()
    {
        return ((int)_status >= (int)Status.REGR);
    }

    public void jotDown(int gameCode, string writer)
    {
        jotDown(gameCode, writer, null, null, null, null);
    }

    public void jotDown(int gameCode, string writer, object d01)
    {
        jotDown(gameCode, writer, d01, null, null, null);
    }

    public void jotDown(int gameCode, string writer, object d01, object d02)
    {
        jotDown(gameCode, writer, d01, d02, null, null);
    }

    public void jotDown(int gameCode, string writer, object d01, object d02, object d03)
    {
        jotDown(gameCode, writer, d01, d02, d03, null);
    }

    public void jotDown(int gameCode, string writer, object d01, object d02, object d03, object d04)
    {
        Jot jot = new Jot
        {
            sheetKey = _sheetKey,
            gameCode = gameCode,
            writer = writer,
            gameTime = this.getTimer(),
            d01 = Convert.ToString(d01),
            d02 = Convert.ToString(d02),
            d03 = Convert.ToString(d03),
            d04 = Convert.ToString(d04)
        };

		string jotJSON = JsonUtility.ToJson (jot);
		RealTimeUpdater.Instance.DoRealTimeUpdate(writer, jotJSON);
        submitJot(jot);
    }

    public int getTimer()
    {
        return (int)(Time.realtimeSinceStartup * 1000);
    }

    private void submitJot(Jot jot)
    {
        if (_gsDirect != null)
        {
            _gsDirect.recordJot(jot);
        }
        else if (Application.isEditor)
        {
            if (_mode != "off")
                editorTrace(jot);
        }
        else if (isRegistered())
        {
            Application.ExternalCall(FXN_JOT_DOWN, jsonStringify(jot, true));
        }
        else
        { 
            _preRegJots.Add(jot);
        }
    }

    private void shellCapture(string gsJSON)
    {
        GsMsg gsm = new GsMsg(gsJSON);
        if (Application.isEditor || gsm.getValue("uKey") == _uKey)
        {
            switch (gsm.getValue("signal"))
            {
                case "registered":
                    if (Convert.ToBoolean(gsm.getValue("success")))
                    {
                        _sheetKey = gsm.getValue("sheetKey");
                        _status = Status.REGR;
                        _holdingCallback = false;
                        if (_hasRegDel)
                        {
                            _regDel(true);
                        }
                        else
                        {
                            _callbackGO.SendMessage(_callbackFxn, true);
                        }
                    }
                    break;
            }
        }
		
    }

    private void directRegistered(string sheetKey)
    {
        _sheetKey = sheetKey;
        _status = Status.REGR;
        _holdingCallback = false;
        _regDel(true);
    }

    private void editorTrace(Jot jot)
    {
        Debug.Log(jot.toString());
    }

    private string jsonStringify(object obj, bool excludeEmpty = false)
    {
        List<string> strList = new List<string>();
        PropertyInfo[] properties = obj.GetType().GetProperties();
        foreach (PropertyInfo property in properties)
        {
            string val;
            bool isEmpty = false;
            if (property.PropertyType == typeof(string))
            {
                val = Convert.ToString(property.GetValue(obj, null));
                if (val.Length == 0)
                    isEmpty = true;
                val = "\"" + val + "\"";
            }
            else
            {
                val = Convert.ToString(property.GetValue(obj, null));
            }
            if (!excludeEmpty || (excludeEmpty && !isEmpty))
                strList.Add("\"" + property.Name + "\": " + val);
        }
        return "{" + String.Join(", ", strList.ToArray()) + "}";
    }

    private class GsMsg
    {
        private List<KeyValPair> kvp = new List<KeyValPair>();

        public GsMsg(string json)
        {
            json = json.Replace("\"", "").Replace("{", "").Replace("}", "");
            string[] retArr = json.Split(',');
            for (int i = 0; i < retArr.Length; i++)
            {
                string[] keyVal = retArr[i].Split(':');
                kvp.Add(new KeyValPair() { key = keyVal[0], value = keyVal[1] });
            }
        }

        public string getValue(string keyName)
        {
            string ret = "";
            if (kvp.Exists(x => x.key == keyName))
            {
                KeyValPair findKV = kvp.Find(x => x.key == keyName);
                ret = findKV.value;
            }
            return ret;
        }
    }

    private class KeyValPair
    {
        public string key { get; set; }

        public string value { get; set; }

        public string asString()
        {
            return key + ": " + value;
        }
    }
}
