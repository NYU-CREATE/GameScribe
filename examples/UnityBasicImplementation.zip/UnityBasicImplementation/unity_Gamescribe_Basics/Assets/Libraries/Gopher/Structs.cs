﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CGE.Gopher {

    class TestObj {
        public string var1 { get; set; }
        public int someInt { get; set; }
        public bool someBool { get; set; }
    }

}
