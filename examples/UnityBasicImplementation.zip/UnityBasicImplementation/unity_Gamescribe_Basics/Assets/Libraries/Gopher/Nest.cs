﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Newtonsoft.Json;


namespace CGE.Gopher
{
	public delegate void GopherDelegate (Gopher gopher);

	public class Nest : MonoBehaviour
	{
		//CONSTANTS
		private const string VERSION = "v1p0";
		private const string ENVIRONMENT = "unity";
		private const string CAPTURE_FXN = "gopherCapture";

		private const string CGE_EVAL = "window.cge=window.cge||{};cge.gopher=cge.gopher||{};cge.gopher.burrow=cge.gopher.burrow||{};";
		private const string CGE_MARCO = "cge.gopher.burrow.marco";
		private const string CGE_GOPHER_IN = "cge.gopher.burrow.gopherIn";
		private const string CGE_SETTINGS = "cge.gopher.burrow.settings";
        
		//Public Properties
        

		//Private Properties
		private static Nest _nest;
		private static string _addressKey;
		private static string _goName;
		private static GameObject _me;
		private bool _initialized = false;
		private bool _registering = false;
		private string _name;
		private string _holeID;
		private bool _hasBurrow = false;
		private List<ActionReg> _registry = new List<ActionReg> ();
		private List<DestX> _destXtab = new List<DestX> ();
        

		//Constructor

		//Accessors
		public static Nest Get {
			get { return _nest ?? (_nest = buildNest ()); }
		}

		public bool initialized { get { return _initialized; } }

		//Public Methods
		public void init (string name)
		{
			if (!_initialized) {
				string nestCom = this.genID ();
				_name = name;
				_holeID = this.genID ();
				RegObj reg = new RegObj {
					ver = VERSION,
					env = ENVIRONMENT,
					addressKey = _addressKey,
					addressName = _name,
					captureGameObject = _goName,
					captureFxn = CAPTURE_FXN,
					regCode = _holeID,
					nestCom = nestCom
				};
				_initialized = true;
				_registering = true;
				_hasBurrow = true;

				this.registerAction (nestCom, handleBurrowGopher);
				this.gopherGo ("burrow", "register", reg, handleBurrowReg);
			}
		}


		public void registerAction (string action, GopherDelegate listener, bool opt_broadcast = false, int opt_tickets = -1)
		{
			bool currReg = false;
			foreach (ActionReg reg in _registry) {
				if (reg.action == action) {
					currReg = true;
					break;
				}
			}
			if (!currReg) {
				ActionReg newReg = new ActionReg ();
				newReg.action = action;
				newReg.callback = listener;
				newReg.broadcast = opt_broadcast;
				newReg.tickets = opt_tickets;
				_registry.Add (newReg);
			}
			if (_initialized && opt_broadcast)
				this.sendPublicActions ();
		}

		public void deregisterAction (string action)
		{
			List<ActionReg> newReg = new List<ActionReg> ();
			foreach (ActionReg reg in _registry) {
				if (reg.action != action)
					newReg.Add (reg);
			}
			_registry = newReg;
			this.sendPublicActions ();
		}

		public void gopherGo (string destination, string action)
		{
			this.gopherGo (destination, action, null, null);
		}

		public void gopherGo (string destination, string action, GopherDelegate opt_callbackFxn)
		{
			this.gopherGo (destination, action, null, opt_callbackFxn);
		}

		public void gopherGo (string destination, string action, object opt_data)
		{
			this.gopherGo (destination, action, opt_data, null);
		}

		public void gopherGo (string destination, string action, object opt_data, GopherDelegate opt_callbackFxn)
		{
			if (_initialized) {
				destination = this.destName (destination);
				if (opt_data == null)
					opt_data = new object ();
				Gopher gopher = new Gopher {
					destination = destination,
					action = action,
					data = opt_data,
					source = _addressKey,
					holeID = _holeID
				};
//                string gs = JsonConvert.SerializeObject(gopher);
				if (opt_callbackFxn != null) {
					string actionID = genID ();
					gopher.returnID = actionID;
					this.registerAction (actionID, opt_callbackFxn, false, 1);
				} else {
					gopher.returnID = "";
				}
				if (_hasBurrow) {
					Application.ExternalCall (CGE_GOPHER_IN, JsonConvert.SerializeObject (gopher));
				} else {
					Debug.LogWarning ("No burrow.");
				}
			} else {
				Debug.LogWarning ("Nest is not initialized. Cannot send Gopher yet.");
			}
		}

		public void gopherReturn (Gopher gopher, object opt_newData = null)
		{
			if (opt_newData == null)
				opt_newData = new object ();
			this.gopherGo (gopher.source, gopher.returnID, opt_newData); 
		}

		public void registerServerNest (string serverName, string serverURL)
		{
			this.registerServerNest (serverName, serverURL, null, null);
		}

		public void registerServerNest (string serverName, string serverURL, object opt_settings)
		{
			this.registerServerNest (serverName, serverURL, null, opt_settings);
		}

		public void registerServerNest (string serverName, string serverURL, GopherDelegate opt_listener, object opt_settings = null)
		{
			if (opt_settings == null)
				opt_settings = new object ();
			RegServer regS = new RegServer {
				sName = serverName,
				sURL = serverURL,
				settings = opt_settings
			};
			this.gopherGo ("burrow", "registerServerNest", regS, opt_listener);
		}

		public void closeNest ()
		{
			_registry = new List<ActionReg> ();
			this.gopherGo ("burrow", "closeNest");
			_hasBurrow = false;
			_holeID = "";
			Destroy (_me);
		}

		//Private Methods
		private static Nest buildNest ()
		{
			_addressKey = Guid.NewGuid ().ToString ();
			_goName = "Nest_" + Guid.NewGuid ().ToString ().Substring (24, 12);
			GameObject cge = GameObject.Find ("CGE");
			if (cge == null) {
				//Debug.Log("null CGE");
				cge = new GameObject ("CGE");
			} else {
				//Debug.Log("found cge");
			}
			if (!Application.isEditor) {
				string ev = CGE_EVAL +
				                        CGE_MARCO + "=" + CGE_MARCO + "||function(){};" +
				                        CGE_GOPHER_IN + "=" + CGE_GOPHER_IN + "||function(){};" +
				                        CGE_SETTINGS + "=" + CGE_SETTINGS + "||function(){};";
				Application.ExternalEval (ev);
			}
			_me = new GameObject (_goName);
			_me.transform.parent = cge.transform;
			DontDestroyOnLoad (cge);
			return _me.AddComponent<Nest> ();
		}

		private void gopherCapture (string gopherString)
		{
			Gopher gopher = JsonConvert.DeserializeObject<Gopher> (gopherString);
			if (gopher.holeID == _holeID) {
				foreach (ActionReg reg in _registry) {
					if (reg.action == gopher.action) {
						if (reg.tickets == -1) {
							reg.callback (gopher);
						} else if (reg.tickets > 0) {
							if (--reg.tickets == 0) {
								Debug.Log ("DEREGESTERING: " + reg.action);
								this.deregisterAction (reg.action);
							}
							reg.callback (gopher);
						}
						break;
					}
				}
			}
		}

		private string destName (string destination)
		{
			foreach (DestX dest in _destXtab) {
				if (dest.destination == destination)
					return dest.burrowDest;
			}
			return destination;
		}

		private void handleBurrowReg (Gopher gopher)
		{
			RegData data = gopher.dataAs<RegData> ();
			if (_registering && data.yourAddress == _addressKey && data.burrowID == gopher.source) {
				_holeID = data.holeID;
				_registering = false;
				_hasBurrow = true;
				this.sendPublicActions ();
			}
		}

		private void handleBurrowGopher (Gopher gopher)
		{

		}

		private void sendPublicActions ()
		{
			List<string> actions = new List<string> ();
			foreach (ActionReg reg in _registry) {
				if (reg.broadcast)
					actions.Add (reg.action);
			}
			gopherGo ("burrow", "actions", actions);
		}

		private string genID (bool full = false)
		{
			string id = Guid.NewGuid ().ToString ();
			if (full)
				return id;
			return id.Substring (24, 12);
		}

		private class RegObj
		{
			public string ver { get; set; }

			public string env { get; set; }

			public string addressKey { get; set; }

			public string addressName { get; set; }

			public string captureGameObject { get; set; }

			public string captureFxn { get; set; }

			public string regCode { get; set; }

			public string nestCom { get; set; }
		}

		private class RegData
		{
			public string holeID { get; set; }

			public string burrowID { get; set; }

			public string yourAddress { get; set; }
		}

		private class RegServer
		{
			public string sName { get; set; }

			public string sURL { get; set; }

			public object settings { get; set; }
		}

		private class DestX
		{
			public string destination { get; set; }

			public string burrowDest { get; set; }
		}

		private class ActionReg
		{
			public string action;
			public GopherDelegate callback;
			public bool broadcast = false;
			public int tickets = -1;
		}

	}
}
