﻿using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace CGE.Gopher {
    public class Gopher {
        public string destination { get; set; }
        public string action { get; set; }
        public object data { get; set; }
        public string source { get; set; }
        public string holeID { get; set; }
        public string returnID { get; set; }

        private List<KeyValPair> _kp = new List<KeyValPair>();

		public T dataValuePure<T>(string keyname) {
			string val = this.dataGetPure(keyname);
			return (T)Convert.ChangeType(val, typeof(T));
		}

		private string dataGetPure(string keyname) {
			string d = data.ToString ();

			return d;
		}

        public T dataAs<T>() {
            return JsonConvert.DeserializeObject<T>(data.ToString());
        }

        public T dataValue<T>(string keyname) {
            string val = this.dataGet(keyname);
            return (T)Convert.ChangeType(val, typeof(T));
        }

        private class KeyValPair {
            public string key { get; set; }
            public string value { get; set; }

            public string asString() {
                return key + ": " + value;
            }
        }

        private string getValue(string keyName) {
            string ret = "";
            if (_kp.Exists(x => x.key == keyName)) {
                KeyValPair findKV = _kp.Find(x => x.key == keyName);
                ret = findKV.value;
            }
            return ret;
        }

        private string dataGet(string keyname) {
            if (_kp.Count == 0) {
				string d = data.ToString().Replace("\"", "").Replace("{", "").Replace("}", "");
				Debug.Log ("d: " + d);
                string[] arr = d.Split(',');
                for (int i = 0; i < arr.Length; i++) {
                    string[] keyVal = arr[i].Split(':');
					Debug.Log(i + ": " + keyVal[0].Trim() + ", " + keyVal[1].Trim());
                    _kp.Add(new KeyValPair() { key = keyVal[0].Trim(), value = keyVal[1].Trim()});
                }
            }
            return this.getValue(keyname);
        }
    }
}
