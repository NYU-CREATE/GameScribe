﻿using UnityEngine;
using System.Collections;

//Seems reduntant to put it in namespace when class has title. No?

public class GameScribeCodes : MonoBehaviour
{
	//Universal codes (1001-1999): Codes general to any game or simulation
	public const int START_GAME = 1001; //[gameName] version [#.#] started;
	public const int GAMESCRIBE_CREATED = 1002; //GameScribe initiated in [off/trace/permissive/strict] mode;

	//High level game descriptors (2001-2999): State changes, game options, etc.
	public const int SETTINGS = 2001; //[userID]

	//Game initiated events (3001-3999): Events triggered within the game itself. Such as enemy deciding to move to new location.
	public const int MENU_START = 3001; //MarineMatcher main menu shown;
	public const int LEVEL_START = 3002; //Level [#-#] starting
	public const int LEVEL_END = 3003; //[totalRatio]

	public const int BUBBLE_SHOWN = 3004; //[creatureId]
	public const int BUBBLE_HIDDEN = 3005; //[creatureId]
	public const int BUBBLE_ACTIVE = 3006; //[creatureId]
	public const int BUBBLE_SHUFFLED = 3007; //[creatureId], [oldPos], [newPos]

	//User interactions (4001-4999): Events triggered by the player; mouse click/hover, keyboard, etc.
	public const int BUBBLE_CHOSEN = 4001; //[creatureId], [bubblesArray]
	public const int COLOR_ANIMAL_SELECTION = 4002; //[creatureId], [null], [color], [shape]
	public const int BUBBLE_DONE = 4003; //[creatureId], [bubblesArray], [color], [shape]

	//Compiled statistics and results (5001-5999): Values compiled from multiple previous events. Such as level play duration and outcome.
	public const int BUBBLE_RESULTS = 5001; //[creatureId], [result], [color], [shape]
	public const int BUBBLE_BONUS = 5002; //[creatureId], [bonus], [streak]

	//(Do not use for game events!) GameScribe hardcodes (9001-9999): Codes reserved for GameScribe API events. Such as a record update event or stop recording event.
}