﻿using UnityEngine;
using System.Collections;
using CGE.Gopher;

public class GameParameters : Singleton<GameParameters>
{
	public static string GameScribeUrl = "https://steinhardtapps.es.its.nyu.edu/create/gamescribe/api.php";
	//GameScribe key given by DREAM
	public const string GameScribeKey = "SANDBOX";

	//"trace" for debugging, "strict" for production
	public string GameScribeMode = "strict";

    public string userID;

    public enum EmotionalDesignStyle
    {
        Hot,
        Cold
    }

    public EmotionalDesignStyle emotionalDesignStyle = EmotionalDesignStyle.Hot;

    public enum ProgressionType
    {
        USER_CHOICE,
        SPEED_FIRST,
        ACCURACY_FIRST
    }

    public ProgressionType progressionType = ProgressionType.USER_CHOICE;

    // if false, the game will start from level 1 each time
    public bool saveProgress = true;

    public int levelSet = 2;

	// called from the game director when app running online
    public void LoadParametersFromDREAM()
    {
		Debug.Log ("GET UNITY GAME PARAMS FROM DREAM");
		Nest.Get.gopherGo("DREAM", "getUnityGameParams", getParamsRemote);
    }

    void getParamsRemote(Gopher g)
    {
        StartCoroutine(getParamsRemoteCoroutine(g));
    }

    IEnumerator getParamsRemoteCoroutine(Gopher g)
	{
		string paramsJson = g.dataValuePure<string>("data");
        JsonUtility.FromJsonOverwrite(paramsJson, this);

		Debug.Log("emotionalDesignStyle: " + emotionalDesignStyle);
        Debug.Log("progressionType: " + progressionType);
        Debug.Log("levelSet: " + levelSet);
        Debug.Log("userID: " + userID);
        Debug.Log("saveProgress: " + saveProgress);

		if (!SandboxGameDirector.Instance.directorInitialized && !GameScribe.Sheet.isRegistered ())
        {
            SandboxGameDirector.Instance.directorInitialized = true;
            yield return StartCoroutine(SandboxGameDirector.Instance.InitializeGameScribe());
		}
		yield break;
    }

    // called from the game director when app running local
    public void LoadParamsLocal()
    {
        StartCoroutine(getParamsLocalCoroutine());
    }

    IEnumerator getParamsLocalCoroutine()
    {
		if (!SandboxGameDirector.Instance.directorInitialized && !GameScribe.Sheet.isRegistered ())
        {
            SandboxGameDirector.Instance.directorInitialized = true;
            if (Application.platform == RuntimePlatform.WebGLPlayer)
            {
                yield return StartCoroutine(SandboxGameDirector.Instance.InitializeGameScribe());
			}
			yield return StartCoroutine(SandboxGameDirector.Instance.InitializeGameScribe());
        }
        yield break;
    }
}