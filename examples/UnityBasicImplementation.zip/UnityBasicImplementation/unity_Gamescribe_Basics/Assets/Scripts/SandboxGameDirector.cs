﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using System.IO;

public class SandboxGameDirector : GameDirector
{
	[SerializeField] private string _gameName = "GameName";

	void Start ()
	{
		StartCoroutine (InitiateGame (_gameName));
	}

	protected override IEnumerator InitiateGame (string gameName)
	{
		yield return base.InitiateGame (gameName);
	}

	//functions linked to buttons to show gamescribe functionality
	public override void LoadMainMenu (string gameName)
	{
		base.LoadMainMenu (_gameName);
	}

	public void BubbleActive () {
		int bubbleId = 2;
		GameScribe.Sheet.jotDown (GameScribeCodes.BUBBLE_ACTIVE, bubbleId.ToString());
	}

	public void BubbleChosen () {
		int bubbleId = 4;
		int[] bubblesArray = { 0, 1, 2, 4, 5, 6, 7 };
		GameScribe.Sheet.jotDown (GameScribeCodes.BUBBLE_CHOSEN, bubbleId.ToString(), bubblesArray.ToString());
	}

	public void BubbleBonus () {
		int bubbleId = 0;
		float bonusPoints = 50.0f;
		int streak = 3;
		GameScribe.Sheet.jotDown (GameScribeCodes.BUBBLE_BONUS, bubbleId.ToString(), bonusPoints.ToString(), streak.ToString());
	}
}