﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using CGE.Gopher;

public abstract class GameDirector: Singleton<GameDirector>
{
	public bool directorInitialized = false;
	
	protected virtual IEnumerator InitiateGame (string gameNameNest)
	{
		if (Application.platform == RuntimePlatform.WebGLPlayer) {
			Debug.Log ("INITIALIZING WEBGL PLAYER SETTINGS");
			yield return StartCoroutine (InitializeNest (gameNameNest));
			GameParameters.Instance.LoadParametersFromDREAM ();
		} else {
			GameParameters.Instance.LoadParamsLocal ();
		}
	}

	private IEnumerator InitializeNest (string gameName)
	{                                
		Nest.Get.init (gameName + "Nest");
		Nest.Get.registerAction ("closeRequest", ExternalCloseRequest, true);
		Nest.Get.gopherGo ("DREAM", "gameStart");
		Debug.Log ("NEST INIT");
		yield break;
	}

	private void ExternalCloseRequest (CGE.Gopher.Gopher gopher)
	{
		//Do anything needed before the game is closed
		Nest.Get.gopherGo ("DREAM", "gameEnd");
		GameScribe.Sheet.unregister ();
		Debug.Log ("NEST AND GAMESCRIBE CLOSED");
	}

	public virtual IEnumerator InitializeGameScribe()
	{
		Debug.Log ("GAMESCRIBE MODE: " + GameParameters.Instance.GameScribeMode);
		GameScribe.Sheet.registerDirect (GameParameters.GameScribeKey, GameParameters.Instance.GameScribeMode, GameParameters.GameScribeUrl, 
			HandleGamescribeRegistered, GameParameters.Instance.userID);
		yield break;
	}

	private void HandleGamescribeRegistered (bool success)
	{
		Debug.Log ("HANDLE GAMESCRIBE REGISTERED: " + success);
		GameScribe.Sheet.launch (GameParameters.Instance.userID);
		GameScribe.Sheet.jotDown (GameScribeCodes.START_GAME, "general", "GameName", 1.2f);
		GameScribe.Sheet.jotDown (GameScribeCodes.GAMESCRIBE_CREATED, "general", GameParameters.Instance.GameScribeMode);
		GameScribe.Sheet.jotDown (GameScribeCodes.SETTINGS, "general", GameParameters.Instance.userID, GameParameters.Instance.emotionalDesignStyle, GameParameters.Instance.levelSet, GameParameters.Instance.progressionType);
	}

	public virtual void LoadMainMenu (string gameName)
	{
		GameScribe.Sheet.jotDown (GameScribeCodes.MENU_START, gameName);
	}
}