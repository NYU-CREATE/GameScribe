﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.IO;

//Maybe make this into a separate LevelDataManager class, and then have a PlayerData class or something
public class SandboxDataManager : Singleton<SandboxDataManager>
{
    public GameLevel currentLevel;

    public void setLevelParams(GameLevel level)
    {
        currentLevel = level;
        GameScribe.Sheet.jotDown(GameScribeCodes.LEVEL_START, getLevelWriter(), currentLevel.name);
    }

    public string getLevelWriter()
	{
		if (currentLevel != null) {
			if (currentLevel.name.Contains("NameLevel"))
			{
				string level_number;
				level_number = currentLevel.name.Replace("NameLevel", "");
				return level_number;
			}
		}
		return "Regular expression failed";
    }
}