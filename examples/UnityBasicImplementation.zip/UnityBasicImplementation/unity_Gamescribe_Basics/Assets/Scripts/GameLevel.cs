﻿using UnityEngine;
using System.Collections;

public class GameLevel : ScriptableObject {
	public string name;
}